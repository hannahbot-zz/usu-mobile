
jquery-ui-map version 3.0-alpha


Documentation: http://code.google.com/p/jquery-ui-map/wiki/Overview

Demo: http://code.google.com/p/jquery-ui-map/

Issues: http://code.google.com/p/jquery-ui-map/issues/list

Discuss at: http://groups.google.com/group/jquery-ui-map-discuss

Packed with http://dean.edwards.name/packer/



